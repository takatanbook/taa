package jp.ac.asojuku.jousisenb.speechmemo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import jp.ac.asojuku.jousisenb.speechmemo.R;

public class WatchMemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch_memo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        Intent intent  = getIntent();
        String[] message     = intent.getStringArrayExtra("memo");
        String[] messageDate = intent.getStringArrayExtra("memodate");
        int[]    messgeId    = intent.getIntArrayExtra("memoId");
        int      count       = intent.getIntExtra("memoCount",0);
        int [] icons = new int[count];
        String[] memo = new String[count];
        String[] memoDate = new String[count];
        int[]    memoId   = new int[count];
        ListView myListView = (ListView) findViewById(R.id.myListView);
        ArrayList<Memo> users = new ArrayList<>();
        for(int i = 0; i < count; i++){
            icons[i] = R.mipmap.ic_launcher;
            memo[i]  = message[i];
            memoDate[i] = messageDate[i];
            memoId[i] = messgeId[i];
        }
        for (int i = 0; i < icons.length; i++) {
            Memo memo1 = new Memo();
            memo1.setIcon(BitmapFactory.decodeResource(
                    getResources(),
                    icons[i]
            ));
            memo1.setMemId(memoId[i]);
            memo1.setMemo(memo[i]);
            memo1.setMemoDate(memoDate[i]);
            users.add(memo1);
        }
        // Adapter - ArrayAdapter - UserAdapter
        UserAdapter adapter = new UserAdapter(this, 0, users);


        // ListViewに表示
        myListView.setEmptyView(findViewById(R.id.emptyView));
        myListView.setAdapter(adapter);
    }
    public class UserAdapter extends ArrayAdapter<Memo> {
        private LayoutInflater layoutInflater;

        public UserAdapter(Context c, int id, ArrayList<Memo> users) {
            super(c, id, users);
            this.layoutInflater = (LayoutInflater) c.getSystemService(
                    Context.LAYOUT_INFLATER_SERVICE
            );
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = layoutInflater.inflate(
                        R.layout.list_item,
                        parent,
                        false
                );
            }
            Memo user = (Memo)getItem(position);
            ((ImageView) convertView.findViewById(R.id.icon))
                    .setImageBitmap(user.getIcon());
            ((TextView) convertView.findViewById(R.id.name))
                    .setText(user.getMemId() + ": "+ user.getMemoDate());
            ((TextView) convertView.findViewById(R.id.comment))
                    .setText(user.getMemo());
            return convertView;
        }
    }
    private class Memo{
        private int memId;
        private String memo;
        private String memoDate;
        private Bitmap icon;
        public int getMemId() {
            return memId;
        }

        public void setMemId(int memId) {
            this.memId = memId;
        }

        public String getMemo() {
            return memo;
        }

        public void setMemo(String memo) {
            this.memo = memo;
        }

        public String getMemoDate() {
            return memoDate;
        }

        public void setMemoDate(String memoDate) {
            this.memoDate = memoDate;
        }



        public Bitmap getIcon() {
            return icon;
        }

        public void setIcon(Bitmap icon) {
            this.icon = icon;
        }



    }

}
