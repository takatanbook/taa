package jp.ac.asojuku.jousisenb.speechmemo.jp.ac.asojuku.jousisenb.speechmemo.dto;

import java.io.Serializable;

/**
 * Created by takamichi on 2016/06/17.
 */
public class MemoDto implements Serializable {
    private int memoId;
    private String memo;
    private String date_time;

    public int getMemoId() {
        return memoId;
    }
    public void setMemoId(int memoId) {
        this.memoId = memoId;
        System.out.println(this.memoId);
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }
    public String getDate_time() {
        return date_time;
    }
    public void setDate_time(String date_time) {
        this.date_time = date_time;
    }
}
