package jp.ac.asojuku.jousisenb.speechmemo;

import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.speech.RecognizerIntent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import jp.ac.asojuku.jousisenb.speechmemo.model.Modeldb;

public class Speach2Activity extends AppCompatActivity {

    // リクエストを識別するための変数宣言。適当な数字でよい
    private static final int REQUEST_CODE = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speach2);
    }
    // タッチイベントが起きたら呼ばれる関数
    public boolean onTouchEvent(MotionEvent event) {
        // 画面から指が離れるイベントの場合のみ実行
        if (event.getAction() == MotionEvent.ACTION_UP) {
            try {
                // 音声認識プロンプトを立ち上げるインテント作成
                Intent intent = new Intent(
                        RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                // 言語モデルをfree-form speech recognitionに設定
                // web search terms用のLANGUAGE_MODEL_WEB_SEARCHにすると検索画面になる
                intent.putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                // プロンプトに表示する文字を設定
                intent.putExtra(
                        RecognizerIntent.EXTRA_PROMPT,
                        "話してください");
                // インテント発行
                startActivityForResult(intent, REQUEST_CODE);
            } catch (ActivityNotFoundException e) {
                // エラー表示
                Toast.makeText(Speach2Activity.this,
                        "ActivityNotFoundException", Toast.LENGTH_LONG).show();
            }
        }
        return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_speach2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    // startActivityForResultで起動したアクティビティが終了した時に呼び出される関数
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 音声認識結果のとき
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            // 結果文字列リストを取得
            ArrayList<String> results = data.getStringArrayListExtra(
                    RecognizerIntent.EXTRA_RESULTS);
            // 取得した文字列を結合
            String resultsString = "";
            for (int i = 0; i < results.size(); i++) {
                resultsString += results.get(i)+";";
            }
            String name = (String) results.get(0);
            Date date = new Date();
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM/dd-HH:mm");

            Modeldb help = new Modeldb(getApplicationContext());
            Modeldb modeldb = new Modeldb(getApplicationContext());
            SQLiteDatabase db = help.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("memo",name );
            values.put("date_time", sdf1.format(date));
            long id = db.insert("speechMemo", null, values);
            // トーストを使って結果表示
            Toast.makeText(this, resultsString, Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Speach2Activity.this,MainActivity.class);
            startActivity(intent);
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
}
